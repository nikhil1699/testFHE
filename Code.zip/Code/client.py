import math
import requests
import json
import sys
import os
import subprocess
import time
import numpy as np
from scipy.stats import entropy
import seal
from seal import Ciphertext, Plaintext, EncryptionParameters, \
    SEALContext, KeyGenerator, Encryptor, Decryptor, \
    FractionalEncoder, Evaluator, EvaluationKeys

# Encryption parameters
poly_mod = 8192     # affects security level, ciphertext size
coef_mod = seal.coeff_modulus_128(poly_mod)     # larger -> more noise budget, lower security
plain_mod = 256     # larger -> less noise budget, more noise budget consumption
dbc = 10    # larger -> faster relinearization, more noise budget consumption; max 60

# Initialize context and generate key pairs
# Batching enabled when (plain_mod mod 2*poly_mod) is congruent to (1 mod 2*poly_mod)
params = EncryptionParameters()
params.set_poly_modulus("1x^"+str(poly_mod)+" + 1")
params.set_coeff_modulus(coef_mod)
params.set_plain_modulus(plain_mod)
context = SEALContext(params)

kg = KeyGenerator(context)
pubkey = kg.public_key()
privkey = kg.secret_key()
evkeys = EvaluationKeys()
kg.generate_evaluation_keys(dbc, evkeys)

# FractionalEncoder int args -- coeffs for low-degree terms; digits of fractional precision
encoder = FractionalEncoder(context.plain_modulus(), context.poly_modulus(), 64, 16)
encr = Encryptor(context, pubkey)
decr = Decryptor(context, privkey)
evl = Evaluator(context)



def generate_array_of_bytes_in_video(videoFile):
    print ('Start decode the video file. ')
    setTime = 60
    decodedByteArray = [0] * setTime
    curser = 0
    frameCount = 0
    command = ['ffprobe', '-show_entries', 'frame=pkt_size,pkt_pts_time', videoFile]
    p = subprocess.Popen(command, stdout=subprocess.PIPE)
    decodedFrames = p.stdout.read().decode('utf-8')
    retcode = p.wait()

    while True:
        if decodedFrames.find('pts_time', curser) == -1:
            print ('Finish decoding ' + videoFile +' for:: ' + str(setTime) + 's')
            break

        frameTime = decodedFrames[decodedFrames.find('pts_time', curser) + 9 :decodedFrames.find('pkt_size', curser) - 1]
        frameSize = decodedFrames[decodedFrames.find('pkt_size', curser) + 9 :decodedFrames.find('[/FRAME]', curser) - 1]

        #print ("------------------------------"+ frameTime + 's:'+frameSize)

        frameCount += 1
        #print ('frame '+str(frameCount) + '===================\ntime = <'+frameTime + '>')
        #print ('size = <'+frameSize + '>')
        if math.floor(float(frameTime)) <= 59:
            decodedByteArray[math.floor(float(frameTime))] += int(frameSize)
        curser = decodedFrames.find('[/FRAME]', curser) + 8
        #print ('curser loaction '+str(curser))
    #print (decodedByteArray)
    # 0 values cause our algorithm to break.  remove them here
    for i in range(0, len(decodedByteArray)):
        decodedByteArray[i] = max(1, decodedByteArray[i])
    return decodedByteArray

def main(username, filename):
    url = "https://localhost:4000/jsonrpc"
    headers = {'content-type': 'application/json'}
    # TODO:  Enable this when we start sharing the request with our counterpart
    #randomRequestId = int.from_bytes(os.urandom(4), sys.byteorder) 
    #TODO: Remove this when we start actually sharing
    randomRequestId = 1337
    #TODO:  We will need to sync the byte array to the start of the other user's video
    byteArray = generate_array_of_bytes_in_video(filename)
    
    # Normalize byte array
    normalizedByteArray = list()
    invertedByteArray = list()
    logByteArray = list()
    byteArraySum = sum(byteArray)
    for i in range (0, len(byteArray)):
        normalizedByteArray.append(float(byteArray[i])/float(byteArraySum))
        invertedByteArray = 1/normalizedByteArray[i]
        logByteArray = math.log(normalizedByteArray[i])

            # TODO: We need to create 3 messages
    #  1) Get in contact with the person we want to share with
    #  1a) (potentially part of 1) exchange the key with that person
    #  2) Send our data to the server

    # For right now I'm just assuming the data is already there and only sending hte last message
    payload = { 
        "method": "detectsimilarity",
        "params": {"username": username, "requestid": randomRequestId, "bytecounts": normalizedByteArray, "inversebytecounts": invertedByteArray, "logbytecounts": logByteArray},
        "jsonrpc":"2.0",
        "id": randomRequestId,
    }
    #TODO:  Verify Cert
    response = requests.post(
        url, data=json.dumps(payload), headers=headers, verify=False).json()
    print (response)

if __name__ == "__main__":
    if len(sys.argv) == 3:
        username = sys.argv[1]
        filename = sys.argv[2]
        main(username, filename)
    else:
        print("You must supply a username and a filename")
