from kivy.app import App
from kivy.lang import Builder 
from kivy.properties import BooleanProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.behaviors import FocusBehavior
from kivy.uix.label import Label
from kivy.uix.recycleview import RecycleView
from kivy.uix.recycleview.views import RecycleDataViewBehavior
from kivy.uix.recycleview.layout import LayoutSelectionBehavior
from kivy.uix.recycleboxlayout import RecycleBoxLayout
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.textinput import TextInput

import base64
from datetime import datetime
import os
import pickle
import pyrebase
import socket
import threading
from videodata import get_video_metadict

from p2pclient import ComparisonClient
from bootstrapserver import BootstrapServer

Builder.load_file('appgui.kv')

TCP_IP = 'localhost'
TCP_PORT = 6001
BUFFER_SIZE = 1024

config = {
        "apiKey": "AIzaSyBsO01VjtIon6fhbHkAZKda9PxXwWW5Usc",
        "authDomain": "fhe-video-sharing.firebaseapp.com",
        "databaseURL": "https://fhe-video-sharing.firebaseio.com/fhe-video-sharing/user-ip",
        "storageBucket": "fhe-video-sharing.appspot.com"
        }

send_file_directory = "sharable-videos"
receive_file_directory = "received-videos"
firebase = pyrebase.initialize_app(config)
db = firebase.database()
userToken = ''

def server_receive_video():
    tcpsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcpsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcpsock.bind((TCP_IP, TCP_PORT))
    while True:
        tcpsock.listen(5)
        #print("Waiting for incoming connections...")
        (conn, (ip,port)) = tcpsock.accept()
        #print('Got connection from ', (ip,port))
        filename = conn.recv(BUFFER_SIZE).decode()
        with open(receive_file_directory + "/" + filename, 'wb') as receivedFile:
            while True:
                data = conn.recv(BUFFER_SIZE)
                if not data:
                    receivedFile.close()
                    break
                # write data to a file
                receivedFile.write(data)
        conn.close()
        print('connection closed')

def start_servers(userToken):
    user_ip_registry = db.get(userToken)
    user_ip_dict = {}
    for user in user_ip_registry.each():
        user_ip_dict[user.key()] = user.val()["ip"]
    bootstrap_server = BootstrapServer(user_ip_dict)
    bootstrap_server.start()
    #server = threading.Thread(target=server_receive_video)
    #server.start()
    #bootstrap_server.join()
    #server.join()

class LoginScreen(Screen):
    email = StringProperty(None)
    password = StringProperty(None)
    def login(self, emailText, passwordText):
        self.email = emailText
        self.password = passwordText
        self.authentication()

    def reset_form(self):
        self.email = StringProperty(None)
        self.password = StringProperty(None)
        self.ids['email'].text = ""
        self.ids['password'].text = ""
    
    def authentication(self):
        # Get a reference to the auth service
        auth = firebase.auth()
        # Log the user in
        user = auth.sign_in_with_email_and_password(self.email, self.password)
        global userToken
        userToken = user['idToken']
        # Get a reference to the database service
        ip = socket.gethostbyname(socket.gethostname())
        email_username = self.email.split("@",1)[0]
        # data to save
        data = {
            "email": self.email,
            "ip": ip,
            "timestamp": datetime.now().isoformat()
        }
        db.child(email_username).set(data, userToken)
        start_servers(userToken)
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'Connected'

    def create_account(self):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'Create an Account'
#### Login ####

#### Connected ####
class ConnectedScreen(Screen):
    def select_user(self):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'Select a User'
        
    def disconnect(self):
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'Login'
        self.manager.get_screen('Login').reset_form()
#### Connected ####

#### CreateAccount ####
class CreateAccountScreen(Screen):
    email = StringProperty(None)
    password = StringProperty(None)
    def create_account(self, emailText, passwordText, passwordConfirmText):
        if(passwordText == passwordConfirmText):
            self.email = emailText
            self.password = passwordText
            firebase = pyrebase.initialize_app(config)
            # Get a reference to the auth service
            auth = firebase.auth()
            # Create the user account
            user = auth.create_user_with_email_and_password(self.email, self.password)
            auth.send_email_verification(user['idToken'])
            # Get a reference to the database service
            self.manager.transition = SlideTransition(direction="right")
            self.manager.current = 'Login'
            self.manager.get_screen('Login').resetForm()

    def reset_form(self):
        self.ids['email'].text = ""
        self.ids['password'].text = ""
        self.ids['passwordConfirm'].text = ""
#### CreateAccount ####

#### SelectUser ####
class SelectUserScreen(Screen):
    def reset_form(self):
        self.ids['other_user_email'].text = ""

    def select_user(self, other_user_email):
        other_user_email_username = other_user_email.split("@", 1)[0]
        if db.child(other_user_email_username).get(userToken):
            ip = db.child(other_user_email_username).get(userToken).val()["ip"]
            #store and use IP for sending file
            self.manager.get_screen('Send File').other_user_email = other_user_email
            self.manager.get_screen('Confirm File Send').other_user_email = other_user_email
            self.manager.get_screen('Confirm File Send').other_user_ip = ip
        else:
            self.reset_form()
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'Send File'
            
#### SelectUser ####

#### ReceiveFile ####
class ReceiveFileScreen(Screen):
    def receive_file(self):
        pass
    # path = "../sharable-videos/"
    # dirs = os.listdir(path)
    # for file in dirs:
    #     my_data = ListProperty(file)
    #     print(file) # this is just to know what exactly is printing file variable
#### ReceiveFile ####

#### SendFile ####
class SendFileScreen(Screen):
    other_user_email = StringProperty("")
    def confirm_send(self, filename):
        self.manager.get_screen('Confirm File Send').filename = filename
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'Confirm File Send'

    def cancel_send(self):
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'Select a User'

class ConfirmSendScreen(Screen):
    FileCompareClient = ComparisonClient()
    comparison_results_text = StringProperty("")
    other_user_email = StringProperty("")
    other_user_ip = StringProperty("")
    filename = StringProperty("")
    def on_enter(self):
        #self.comparison_results_text = "Performing comparison of video data."
        comparison_results = str(self.FileCompareClient.compare_with_other_user(self.other_user_email, self.filename))
        if(float(comparison_results) >= 0):
            self.comparison_results_text = "The file comparison has returned this value: " + comparison_results + "."
        else:
            self.comparison_results_text = self.other_user_email + " does not appear to have a video proving their co-presence.\n We do not recommend sending the video."

    def send_file(self):
        other_user_email_username = self.other_user_email.split("@",1)[0]
        self.FileCompareClient.send_video(other_user_email_username, self.filename)
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'Select a User'

    def send_file_socket(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # replace TCP_IP with IP of other person
        sock.connect((self.other_user_ip, TCP_PORT))
        videoFile = open(send_file_directory + "/" + self.filename,'rb')
        sock.send(self.filename.encode())
        while True:
            bytesRead = videoFile.read(BUFFER_SIZE)
            while (bytesRead):
                sock.send(bytesRead)
                #print('Sent ',repr(l))
                bytesRead = videoFile.read(BUFFER_SIZE)
            if not bytesRead:
                videoFile.close()
                sock.close()
                break
        # sock.send(videoBytes)
        # videoBytes.close()
        # sock.close()
        else:
            videoFile.close()
            sock.close()
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'Select a User'
        
    def cancel(self):
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'Send File'

class SelectableRecycleBoxLayout(FocusBehavior, LayoutSelectionBehavior, RecycleBoxLayout):
    ''' Adds selection and focus behaviour to the view. '''
    pass

class SelectableLabel(RecycleDataViewBehavior, Label):
    ''' Add selection support to the Label '''
    index = None
    textSelected = StringProperty("")
    selected = BooleanProperty(False)
    selectable = BooleanProperty(True)
    def refresh_view_attrs(self, rv, index, data):
        ''' Catch and handle the view changes '''
        self.index = index
        return super(SelectableLabel, self).refresh_view_attrs(
            rv, index, data)

    def on_touch_down(self, touch):
        ''' Add selection on touch down '''
        if super(SelectableLabel, self).on_touch_down(touch):
            return True
        if self.collide_point(*touch.pos) and self.selectable:
            return self.parent.select_with_touch(self.index, touch)

    def apply_selection(self, rv, index, is_selected):
        ''' Respond to the selection of items in the view. '''
        self.selected = is_selected
        if is_selected:
            #print("selection changed to {0}".format(rv.data[index]))
            rv.filename = rv.data[index]["text"]
            videoMetadict = get_video_metadict(rv.filename)
            rv.fileCreationDate = videoMetadict["Creation date"]
            rv.fileDuration = videoMetadict["Duration"]
            #set_video_info(self,name=filename, creationDate=fileCreationDate, duration=fileDuration)
        #else:
            #print("selection removed for {0}".format(rv.data[index]))
    
class FileSelectRV(RecycleView):
    filename = StringProperty("")
    fileCreationDate = StringProperty("")
    fileDuration = StringProperty("")
    def __init__(self, **kwargs):
        super(FileSelectRV, self).__init__(**kwargs)
        #self.data = [{'text': str(x)} for x in range(100)]
        self.data = [{'text': file} for file in os.listdir("sharable-videos")]
#### SendFile ####

class LoginApp(App):
    def build(self):
        manager = ScreenManager()
        manager.add_widget(LoginScreen(name='Login'))
        manager.add_widget(ConnectedScreen(name='Connected'))
        manager.add_widget(CreateAccountScreen(name='Create an Account'))
        return manager

class SelectUserApp(App):
    def build(self):
        manager = ScreenManager()
        manager.add_widget(SelectUserScreen(name='Select a User'))
        return manager

class ReceiveFileApp(App):
    def build(self):
        manager = ScreenManager()
        manager.add_widget(ReceiveFileScreen(name='Receive a File'))
        return manager

class SendFileApp(App):
    def build(self):
        manager = ScreenManager()
        manager.add_widget(SendFileScreen(name='Send File'))
        manager.add_widget(ConfirmSendScreen(name='Confirm File Send'))
        return manager

class MainApp(App):
    def build(self):
        manager = ScreenManager()
        Login = LoginScreen(name='Login')
        Connected = ConnectedScreen(name='Connected')
        CreateAccount = CreateAccountScreen(name='Create an Account')
        SelectUser = SelectUserScreen(name='Select a User')
        SendFile = SendFileScreen(name='Send File')
        ReceiveFile = ReceiveFileScreen(name='Receive a File')
        ConfirmSend = ConfirmSendScreen(name='Confirm File Send')
        manager.add_widget(Login)
        manager.add_widget(Connected)
        manager.add_widget(CreateAccount)
        manager.add_widget(SelectUser)
        manager.add_widget(SendFile)
        manager.add_widget(ReceiveFile)
        manager.add_widget(ConfirmSend)
        # manager.add_widget(LoginScreen(name='Login'))
        # manager.add_widget(ConnectedScreen(name='Connected'))
        # manager.add_widget(CreateAccountScreen(name='Create an Account'))
        # manager.add_widget(SelectUserScreen(name='Select a User'))
        # manager.add_widget(SendFileScreen(name='Send File'))
        # manager.add_widget(ReceiveFileScreen(name='Receive a File'))
        # manager.add_widget(ConfirmSendScreen(name='Confirm File Send'))
        return manager

if __name__ == '__main__':
    # LoginApp().run()
    # SelectUserApp().run()
    # ReceiveFileApp().run()
    # SendFileApp().run()
    MainApp().run()