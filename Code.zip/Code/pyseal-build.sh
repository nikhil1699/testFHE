#!/bin/bash

# Script to build PySEAL locally, modified from original Dockerfile
# Run this from cloned PySEAL directory

apt-get -qqy update && apt-get install -qqy \
	g++ \
	git \
	make \
	python3 \
	python3-dev \
	python3-pip \
	sudo \
        libdpkg-perl \
	--no-install-recommends

# Build SEAL libraries
cd SEAL/
chmod +x configure
sed -i -e 's/\r$//' configure
./configure
make
cd ..
LD_LIBRARY_PATH=$(pwd)/bin:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

# Build SEAL C++ example
cd SEALExamples/
make

# Build SEAL Python wrapper
cd ..
cp bin/libseal.a bin/sealexamples SEAL/bin
cd SEALPython/
pip3 install --upgrade pip
pip3 install setuptools
pip3 install -r requirements.txt
git clone https://github.com/pybind/pybind11.git
cd pybind11/
git checkout a303c6fc479662fd53eaa8990dbc65b7de9b7deb
cd ..
python3 setup.py build_ext -i
cd ..
PYTHONPATH=$PYTHONPATH:$(pwd)/SEALPython:$(pwd)/bin
export PYTHONPATH
