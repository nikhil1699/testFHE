#!/usr/bin/env python3.6

# Client-server model to compute similarity measures using PySEAL FHE library

from typing import List
import time
import numpy as np
from scipy.stats import entropy, energy_distance
import multiprocessing
import seal
from seal import Ciphertext, Plaintext, EncryptionParameters, \
    SEALContext, KeyGenerator, Encryptor, Decryptor, \
    FractionalEncoder, Evaluator, EvaluationKeys


# Kullbach-Leibler Divergence of lists X and Y implemented with FHE
# Returns encrypted result
def kld(X: List[Ciphertext], logX: List[Ciphertext], logY: List[Ciphertext]):
    if len(X) > poly_mod or len(logX) != len(logY):
        raise ValueError("Improper list lengths")
    
    for i in range(len(logX)):
        evl.sub(logX[i], logY[i])
        #print("KLD noise budget pre-mult (iter. " + str(i+1) + "): " + str(decr.invariant_noise_budget(lx[i])) + " bits")
        evl.multiply(logX[i], X[i])
        #print("KLD noise budget (iter. " + str(i+1) + "): " + str(decr.invariant_noise_budget(lx[i])) + " bits")
    
    KLD_enc = Ciphertext()
    evl.add_many(logX, KLD_enc)
    return KLD_enc

# KLD with multiprocessing
# Returns encrypted result
def kld_mp(x: Ciphertext, logx: Ciphertext, logy: Ciphertext):
    evl.sub(logx, logy)
    evl.multiply(logx, x)
    return logx

# Cramer's distance between two cumulative distribution functions P and Q
# Note: sqrt the distance to get metric
# Returns encrypted result
def cramer(P: List[Ciphertext], Q: List[Ciphertext]):
    c_result = Ciphertext()
    encr.encrypt(encoder.encode(0.), c_result)
    for i in range(len(P)):
        evl.sub(P[i], Q[i])
        evl.square(P[i])
        evl.add(c_result, P[i])

    return c_result

# Cramer's distance for multiprocessing
# Returns encrypted result
def cramer_mp(p: Ciphertext, q: Ciphertext):
    evl.sub(p, q)
    evl.square(p)
    return p

# Bhattacharyya coefficient between sqrtX and sqrtY
def bc_coef(sqrtX: List[Ciphertext], sqrtY: List[Ciphertext]):
    for i in range(len(sqrtX)):
        evl.multiply(sqrtX[i], sqrtY[i])
    
    c_result = Ciphertext()
    evl.add_many(sqrtX, c_result)
    return c_result

# Bhattacharyya coefficient with multiprocessing
def bc_coef_mp(sqrtx: Ciphertext, sqrty: Ciphertext):
    evl.multiply(sqrtx, sqrty)
    return sqrtx

'''
# Power series approximation of log(x) with FHE, up to N terms
# log(x) = 2*sum[1/(2k + 1) * ((x - 1)/(x + 1))^(2k + 1)]
# Returns encrypted result
def _log(x: Ciphertext, xinv: Ciphertext, N: int):
    _scalefactor = 100.  # Scale factor for log, normally should not be modified
    c_result = Ciphertext()
    encr.encrypt(encoder.encode(0.), c_result)
    x_enc = Ciphertext(x)
    evl.multiply_plain(x_enc, encoder.encode(_scalefactor))  # scaling the value up
    evl.sub_plain(x_enc, encoder.encode(1.))
    xinv_enc = Ciphertext(xinv)     # Assuming xinv is of form: 1/(_scalefactor*x + 1)
    
    for k in range(N):
        kterm = 2*k + 1
        kterm_inv = encoder.encode(2./kterm)
        c_temp = Ciphertext(x_enc)
        evl.multiply(c_temp, xinv_enc)
        evl.relinearize(c_temp, evkeys)
        evl.exponentiate(c_temp, kterm, evkeys)
        evl.multiply_plain(c_temp, kterm_inv)
        evl.add(c_result, c_temp)
        #print("Noise budget (iter. " + str(k+1) + "): " + str(decr.invariant_noise_budget(c_result)) + " bits")
    
    evl.sub_plain(c_result, encoder.encode(np.log(_scalefactor)))    # unscale
    
    #p = Plaintext()
    #decr.decrypt(x, p)
    #p = encoder.decode(p)
    #p_result = Plaintext()
    #decr.decrypt(c_result, p_result)
    #p_result = encoder.decode(p_result)
    #print("Approximation of log(" + str(p) + "): " + str(p_result) + " -- Actual: " + str(np.log(p)))
    return c_result

# A hacky implementation of 4th-order Taylor series of 1/(x+y+2), around point (a,b) = (0,1)
# Convergence conditions:  0 < x < 1,  0 < y < 1
# Returns encrypted result
def _xpyinv(x: Ciphertext, y: Ciphertext):
    c_result = Ciphertext()
    encr.encrypt(encoder.encode(0.), c_result)
    b = 1.   # constant

    n = 4
    while n > 0:
        c_xn = Ciphertext(x)
        c_yn = Ciphertext(y)
        evl.sub_plain(c_yn, encoder.encode(b))
        evl.exponentiate(c_xn, n, evkeys)
        
        k = n - 1
        while k > 0:
            c_xk = Ciphertext(x)
            c_yk = Ciphertext(c_yn)
            evl.exponentiate(c_xk, k, evkeys)
            evl.exponentiate(c_yk, n - k, evkeys)
            evl.multiply(c_xk, c_yk)
            evl.relinearize(c_xk, evkeys)
            if k == n - k:
                evl.multiply_plain(c_xk, encoder.encode(float(np.math.factorial(k+1))))
            else:
                evl.multiply_plain(c_xk, encoder.encode(float(n)))
            evl.add(c_xn, c_xk)
            k -= 1
            #print("=Noise budget c_xn (iter. " + str(k+1) + "): " + str(decr.invariant_noise_budget(c_xn)) + " bits")
        
        evl.exponentiate(c_yn, n, evkeys)
        evl.add(c_yn, c_xn)
        evl.multiply_plain(c_yn, encoder.encode(1/(b + 2)**(n+1)))
        if n % 2 != 0:
            evl.negate(c_yn)
        evl.add(c_result, c_yn)
        n -= 1
        #print("Noise budget c_result (iter. " + str(n+1) + "): " + str(decr.invariant_noise_budget(c_result)) + " bits")
    
    evl.add_plain(c_result, encoder.encode(1/(b + 2)))
    p_result = Plaintext()
    decr.decrypt(c_result, p_result)
    p_result = encoder.decode(p_result)
    print("1/(x+y+2) = " + str(p_result))
    return c_result

# Taylor expansion of 1/x with N iterations
# Convergence condition:  |1 - x| < 1
# Returns encrypted result
def _xinv(x: Ciphertext, N: int):
    c_result = Ciphertext()
    encr.encrypt(encoder.encode(0.), c_result)
    for k in range(N):
        c_temp = Ciphertext(x)
        if k == 0:
            encr.encrypt(encoder.encode(1.), c_temp)
        else:
            evl.sub_plain(c_temp, encoder.encode(1.))
            evl.exponentiate(c_temp, k, evkeys)
        if k % 2 != 0:
            evl.negate(c_temp)
        evl.add(c_result, c_temp)

    #p_result = Plaintext()
    #decr.decrypt(c_result, p_result)
    #p_result = encoder.decode(p_result)
    #print("1/x: " + str(p_result))
    return c_result

# Jensen-Shannon Divergence of lists X and Y implemented with FHE
def jsd(X, Y):
    XY_enc = [None for i in range(len(X))]
    XYinv_enc = [None for i in range(len(X))]
    for i in range(len(XY_enc)):
        Xi_enc = Ciphertext()
        Yi_enc = Ciphertext()
        encr.encrypt(encoder.encode(float(X[i])), Xi_enc)
        encr.encrypt(encoder.encode(float(Y[i])), Yi_enc)
        XY_enc[i] = Ciphertext(Xi_enc)
        evl.add(XY_enc[i], Yi_enc)
        evl.multiply_plain(XY_enc[i], encoder.encode(1./2))
        c_temp = Ciphertext(XY_enc[i])
        evl.add_plain(c_temp, encoder.encode(1./20))
        XYinv_enc[i] = _xinv(c_temp, 5)     # Evaluate 1/((Xi+Yi)/2 + 1); needed for KLD
        evl.multiply_plain(XYinv_enc[i], encoder.encode(1./20))
    
    kld_XM = kld(X, XY_enc, XYinv_enc)
    kld_YM = kld(Y, XY_enc, XYinv_enc)
    JSD = (kld_XM + kld_YM)/2
    return JSD
'''


if __name__ == '__main__':
    # Encryption parameters
    poly_mod = 8192     # affects security level, ciphertext size
    coef_mod = seal.coeff_modulus_128(poly_mod)     # larger -> more noise budget, lower security
    plain_mod = 512     # larger -> less noise budget, more noise budget consumption
    dbc = 60    # larger -> faster relinearization, more noise budget consumption; max 60

    # Initialize context and generate key pairs
    # Batching enabled when (plain_mod mod 2*poly_mod) is congruent to (1 mod 2*poly_mod)
    params = EncryptionParameters()
    params.set_poly_modulus("1x^" + str(poly_mod) + " + 1")
    params.set_coeff_modulus(coef_mod)
    params.set_plain_modulus(plain_mod)
    context = SEALContext(params)

    kg = KeyGenerator(context)
    pubkey = kg.public_key()
    privkey = kg.secret_key()
    evkeys = EvaluationKeys()
    kg.generate_evaluation_keys(dbc, evkeys)

    # FractionalEncoder int args -- coeffs for low-degree terms; digits of fractional precision
    encoder = FractionalEncoder(context.plain_modulus(), context.poly_modulus(), 64, 32)
    encr = Encryptor(context, pubkey)
    decr = Decryptor(context, privkey)
    evl = Evaluator(context)


    lengths = {60, }
    time1_kld = [0 for i in range(len(lengths))]    # runtimes for FHE-implemented
    time2_kld = [0 for i in range(len(lengths))]    # runtimes for scipy entropy()
    time1_cd = [0 for i in range(len(lengths))]
    time2_cd = [0 for i in range(len(lengths))]
    time1_bc = [0 for i in range(len(lengths))]
    time2_bc = [0 for i in range(len(lengths))]
    data = np.loadtxt('data_1200_normalized.txt')

    mp = True  # multiprocessing flag
    t_i = 0
    l = 60
    while l in lengths:
        X = data[:l, 0]
        Y = data[:l, 1]
        # Re-normalize
        X = X / np.sum(X)
        Y = Y / np.sum(Y)
        
        # Receiving pre-computed encrypted data
        X_enc = [Ciphertext() for i in range(len(X))]
        logX_enc = [Ciphertext() for i in range(len(X))]
        Y_enc = [Ciphertext() for i in range(len(Y))]
        logY_enc = [Ciphertext() for i in range(len(Y))]
        sqrtX_enc = [Ciphertext() for i in range(len(X))]
        sqrtY_enc = [Ciphertext() for i in range(len(Y))]
        for i in range(len(X)):
            encr.encrypt(encoder.encode(X[i]), X_enc[i])
            encr.encrypt(encoder.encode(np.log(X[i])), logX_enc[i])
            encr.encrypt(encoder.encode(Y[i]), Y_enc[i])
            encr.encrypt(encoder.encode(np.log(Y[i])), logY_enc[i])
            encr.encrypt(encoder.encode(np.sqrt(X[i])), sqrtX_enc[i])
            encr.encrypt(encoder.encode(np.sqrt(Y[i])), sqrtY_enc[i])

        cdfX = [X[0]]
        cdfY = [Y[0]]
        for i in range(1, len(X)):
            cdfX.append(cdfX[i-1] + X[i])
            cdfY.append(cdfY[i-1] + Y[i])
        
        cdfX_enc = [Ciphertext() for i in range(len(cdfX))]
        cdfY_enc = [Ciphertext() for i in range(len(cdfY))]
        for i in range(len(cdfX)):
            encr.encrypt(encoder.encode(cdfX[i]), cdfX_enc[i])
            encr.encrypt(encoder.encode(cdfY[i]), cdfY_enc[i])
        
        ## KLD ##
        t_0 = time.time()
        if mp:
            pool = multiprocessing.Pool()
            results = [pool.apply_async(func=kld_mp, args=(X_enc[n], logX_enc[n], logY_enc[n]))
                        for n in range(len(X_enc))]
            pool.close()
            pool.join()
            results = [r.get() for r in results]
            KLD_c = Ciphertext()
            evl.add_many(results, KLD_c)
        else:
            KLD_c = kld(X_enc, logX_enc, logY_enc)
        
        evl.relinearize(KLD_c, evkeys)
        #print("Noise budget (post-relin. KLD_c): " + str(decr.invariant_noise_budget(KLD_c)) + " bits")
        # Decryption done locally by user
        KLD_p = Plaintext()
        decr.decrypt(KLD_c, KLD_p)
        KLD_p = encoder.decode(KLD_p)
        t_f = time.time()
        print("KLD (FHE): " + str(KLD_p))
        time1_kld[t_i] = t_f - t_0

        t_0 = time.time()
        print("KLD (scipy): " + str(entropy(X, Y)))
        t_f = time.time()
        time2_kld[t_i] = t_f - t_0
        #########
        
        ## Cramer's distance ##
        t_0 = time.time()        
        if mp:
            pool = multiprocessing.Pool()
            results = [pool.apply_async(func=cramer_mp, args=(cdfX_enc[n], cdfY_enc[n]))
                        for n in range(len(cdfX_enc))]
            pool.close()
            pool.join()
            results = [r.get() for r in results]
            cramer_c = Ciphertext()
            evl.add_many(results, cramer_c)
        else:
            cramer_c = cramer(cdfX_enc, cdfY_enc)
        
        #print("Noise budget (cramer_c): " + str(decr.invariant_noise_budget(cramer_c)) + " bits")
        # Decryption done locally by user
        cramer_p = Plaintext()
        decr.decrypt(cramer_c, cramer_p)
        cramer_p = encoder.decode(cramer_p)
        t_f = time.time()
        print("Cramer (FHE): " + str(cramer_p))
        time1_cd[t_i] = t_f - t_0

        t_0 = time.time()
        cramer_sp = 0
        for i in range(len(X)):
            testval = (cdfX[i] - cdfY[i])**2
        #    print (str(testval))
            cramer_sp = cramer_sp + testval

        print("Cramer (scipy): " + str(cramer_sp))
        t_f = time.time()
        time2_cd[t_i] = t_f - t_0
        #########
        
        ## Bhattacharyya coef. ##
        t_0 = time.time()
        if mp:
            pool = multiprocessing.Pool()
            results = [pool.apply_async(func=bc_coef_mp, args=(sqrtX_enc[n], sqrtY_enc[n]))
                        for n in range(len(sqrtX_enc))]
            pool.close()
            pool.join()
            results = [r.get() for r in results]
            bc_c = Ciphertext()
            evl.add_many(results, bc_c)
        else:
            bc_c = bc_coef(sqrtX_enc, sqrtY_enc)

        evl.relinearize(bc_c, evkeys)
        # Decryption done locally by user
        bc_p = Plaintext()
        decr.decrypt(bc_c, bc_p)
        bc_p = encoder.decode(bc_p)
        t_f = time.time()
        print("Bhattacharyya coef. (FHE): " + str(bc_p))
        time1_bc[t_i] = t_f - t_0

        t_0 = time.time()
        bc_actual = 0
        for i in range(len(X)):
            bc_actual += np.sqrt(X[i]*Y[i])
        
        t_f = time.time()
        print("Bhattacharyya coef. (actual): " + str(bc_actual))
        time2_bc[t_i] = t_f - t_0
        #########
        
        '''
        # JSD
        #for i in range(len(X)):
        #    print("Expected M^-1 + 1: " + str(1/((X[i] + Y[i])/2 + 1)))
        #    print("Expected log(X[i]): " + str(np.log(X[i])))
        #    print("Expected log(M): " + str(np.log(0.5*(X[i] + Y[i]))))
        t_0 = time.time()
        print("JSD (FHE): " + str(jsd(X, Y)))
        t_f = time.time()
        time1_jsd[t_i] = t_f - t_0

        t_0 = time.time()
        M = 0.5*(X + Y)
        print("JSD (scipy): " + str(0.5*(entropy(X, M) + entropy(Y, M))))
        t_f = time.time()
        time2_jsd[t_i] = t_f - t_0
        '''

        t_i += 1
        l += 10
        input("== Press enter to continue.. ==")

    print("KLD runtimes (FHE) [s]: " + str(time1_kld))
    print("KLD runtimes (scipy) [s]: " + str(time2_kld))
    print("Cramer runtimes (FHE) [s]: " + str(time1_cd))
    print("Cramer runtimes (scipy) [s]: " + str(time2_cd))
    print("Bhattacharyya runtimes (FHE) [s]: " + str(time1_bc))
    print("Bhattacharyya runtimes (actual) [s]: " + str(time2_bc))
