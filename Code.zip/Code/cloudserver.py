from werkzeug.wrappers import Request, Response
from werkzeug.serving import run_simple
from werkzeug.serving import make_ssl_devcert
import os
from jsonrpc import JSONRPCResponseManager, dispatcher
import time
pendingRequests = dict()
resultsToSend = dict()


@dispatcher.add_method
def detectsimilarity(**kwargs):
    #TODO:  Put similarity detection code here
#    print ("status")
#    print (pendingRequests)
#    print (resultsToSend)
#    print ("starting")

    username = kwargs['username']
    requestId = kwargs['requestid']
    byteCounts = kwargs['bytecounts']
    inverseByteCounts = kwargs['inversebytecounts']
    logByteCounts = kwargs['logbytecounts']

    if (username, requestId) in pendingRequests:
        #TODO:  Put similiarty code here
        # FAKING WHAT MIGHT HAPPEN 
 #       print (str(username) + " and " + str(requestId) + " are joining")
        resultsToSend[(username, requestId)] = (0.1, 0.4)
 #       print ("joined")
    else:
        pendingRequests[(username,requestId)] = (byteCounts, inverseByteCounts, logByteCounts)
        while (username, requestId) not in resultsToSend:
 #           print (str(username) + " and " + str(requestId) + " waiting for a join")
            time.sleep(1)

    print ("returning")
#    print (kwargs['username'])
#    print (kwargs['randomRequestId'])
#    print (kwargs['bytecounts'])
#    print (kwargs['inversebytecounts'])
#    print (kwargs['logbytecounts'])

#For testing we can compare these values against a known data sample until I fix the asynch issue


    #TODO:  return the KLD and JSD scores
    return resultsToSend[(username, requestId)]

@Request.application
def application(request):

    response = JSONRPCResponseManager.handle(
        request.data, dispatcher)

    return Response(response.json, mimetype='application/json')


if __name__ == '__main__':
    if not os.path.isfile('./key.crt') or not os.path.isfile('./key.key'):
        make_ssl_devcert('./key', host='localhost')
    run_simple('localhost', 4000, application, threaded=True, ssl_context=('./key.crt','./key.key'))
