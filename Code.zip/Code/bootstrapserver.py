from werkzeug.wrappers import Request, Response
from werkzeug.serving import run_simple
from werkzeug.serving import make_ssl_devcert
import os
from jsonrpc import JSONRPCResponseManager, dispatcher
import time
from threading import Thread

peerRegistry = dict()

class BootstrapServer(Thread):
    def __init__(self, user_ip_dict):
        Thread.__init__(self)
        global peerRegistry
        peerRegistry = user_ip_dict

    def run(self):
        if not os.path.isfile('./key.crt') or not os.path.isfile('./key.key'):
            make_ssl_devcert('./key', host='localhost')
        run_simple('localhost', 6000, application, threaded=True, ssl_context=('./key.crt','./key.key'))

@dispatcher.add_method
def register(**kwargs):   #TODO:   Use more robust P2P library that can handle NATs
    username = kwargs['username']
    #  print (username)
    address = kwargs['address']
    #  print (address)
    portnum = kwargs['portnum']
    # print (portnum)
    peerRegistry[username] = address
    return ("ok",)

@dispatcher.add_method
def unregister(**kwargs):
    username = kwargs['username']
    peerRegistry.pop(username, None)
    return ("ok",)

@dispatcher.add_method
def find(**kwargs):
    username = kwargs['username']
    userInfo = peerRegistry[username]
    return (userInfo,)

@Request.application
def application(request):
    response = JSONRPCResponseManager.handle(
        request.data, dispatcher)
    return Response(response.json, mimetype='application/json')


if __name__ == '__main__':
    user_ip_dict = {}
    ServerInstance = BootstrapServer(user_ip_dict)
    #if not os.path.isfile('./key.crt') or not os.path.isfile('./key.key'):
        #make_ssl_devcert('./key', host='localhost')
    #run_simple('localhost', 6000, ServerInstance.application, threaded=True, ssl_context=('./key.crt','./key.key'))
