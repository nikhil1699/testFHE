from hachoir.parser import createParser
from hachoir.metadata import extractMetadata
from itertools import combinations
from datetime import datetime, timedelta

import csv
import math
import os
import subprocess

target_video_directory = "sharable-videos"
data_directory = "video-data"

def check_video_directory():
    for (_, _, videoFiles) in os.walk(target_video_directory):
        for videoName in videoFiles:
            write_video_data(videoName)

def write_video_data(filename):
    dataExists = os.path.exists(data_directory + '/' + filename + '.csv')
    if not dataExists:
        print("Creating video data for " + filename)
        videoByteData = generate_array_of_bytes_in_video(target_video_directory + "/" + filename)
        with open(data_directory + '/' + filename + '.csv', mode='w') as data_file:
            videoDataWriter = csv.writer(data_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            for byteData in videoByteData:
                videoDataWriter.writerow([byteData])
    return dataExists

def read_video_data(filename):
    videoData = []
    write_video_data(filename)
    with open(data_directory + "/" + filename + '.csv', newline='') as videoDataFile:
        videoDataReader = csv.reader(videoDataFile, delimiter='\n')
        for row in videoDataReader:
            videoData.append(int(row[0]))
    return videoData

def get_video_metadict(filename):
    parser = createParser(target_video_directory + "/" + filename)
    if not parser:
        print("Unable to parse file")
        exit(1)
    with parser:
        try:
            metadata = extractMetadata(parser)
        except Exception as err:
            print("Metadata extraction error:%s" % err)
            metadata = None
    if not metadata:
        print("Unable to extract metadata")
        exit(1)
    metaDict = metadata.exportDictionary()["Metadata"]
    return metaDict

def get_video_start_time(creationDate):
    #print("Metadict creation date " + creationDate)
    videoStartTime = datetime.strptime(creationDate, '%Y-%m-%d %H:%M:%S')
    #print("Datetime start time " + videoStartTime)
    return videoStartTime

def get_video_end_time(duration, videoStartTime):
    #print("Metadict duration " + duration)
    for x in range(1, 5):
        for format in combinations(["%H hour", "%M min", "%S sec", "%f ms"], x):
            formatCombo = " ".join(format).strip()
            try:
                durationDT = datetime.strptime(duration, formatCombo)
            except ValueError:
                pass
    #print("Datetime duration" + durationDT)
    videoEndTime = videoStartTime + timedelta(hours=durationDT.hour, minutes=durationDT.minute,
                                seconds=durationDT.second, microseconds=durationDT.microsecond)
    #print(videoEndTime)
    return videoEndTime

def get_videos_in_time_range(targetStartTime, targetEndTime):
    matchingVideos = list()
    for (_, _, videoFiles) in os.walk(target_video_directory):
        for videoName in videoFiles:
            #print("Checking video " + videoName)
            metaDict = get_video_metadict(videoName)
            videoStartTime = get_video_start_time(metaDict["Creation date"])
            videoEndTime = get_video_end_time(metaDict["Duration"], videoStartTime)
            if((videoStartTime <= targetStartTime and videoEndTime > targetStartTime) or (videoStartTime >= targetStartTime and videoStartTime < targetEndTime)):
                matchingVideos.append(videoName)
    return matchingVideos

#TODO:  Don't generate this on the fly.  We should scan in the background and then create files to load in
def generate_array_of_bytes_in_video(videoFile):
    print ('Start decode the video file. ')
    setTime = 60
    decodedByteArray = [0] * setTime
    curser = 0
    frameCount = 0
    command = ['ffprobe', '-show_entries', 'frame=pkt_size,pkt_pts_time', videoFile]
    p = subprocess.Popen(command, stdout=subprocess.PIPE)
    decodedFrames = p.stdout.read().decode('utf-8')
    retcode = p.wait()

    while True:
        if decodedFrames.find('pts_time', curser) == -1:
            print ('Finish decoding ' + videoFile +' for:: ' + str(setTime) + 's')
            break

        frameTime = decodedFrames[decodedFrames.find('pts_time', curser) + 9 :decodedFrames.find('pkt_size', curser) - 1]
        frameSize = decodedFrames[decodedFrames.find('pkt_size', curser) + 9 :decodedFrames.find('[/FRAME]', curser) - 1]

        #print ("------------------------------"+ frameTime + 's:'+frameSize)

        frameCount += 1
        #print ('frame '+str(frameCount) + '===================\ntime = <'+frameTime + '>')
        #print ('size = <'+frameSize + '>')
        if math.floor(float(frameTime)) <= 59:
            decodedByteArray[math.floor(float(frameTime))] += int(frameSize)
        curser = decodedFrames.find('[/FRAME]', curser) + 8
        #print ('curser loaction '+str(curser))
    #print (decodedByteArray)
    # 0 values cause our algorithm to break.  remove them here
    for i in range(0, len(decodedByteArray)):
        decodedByteArray[i] = max(1, decodedByteArray[i])
    return decodedByteArray