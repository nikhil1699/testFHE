// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

#define SEAL_VERSION ""
/* #undef SEAL_DEBUG */
/* #undef SEAL_USE_IF_CONSTEXPR */
/* #undef SEAL_USE_MAYBE_UNUSED */
/* #undef SEAL_USE_STD_BYTE */
/* #undef SEAL_USE_SHARED_MUTEX */
/* #undef SEAL_ENFORCE_HE_STD_SECURITY */
/* #undef SEAL_ALLOW_TRANSPARENT_CIPHERTEXT */
/* #undef SEAL_USE_INTRIN */
/* #undef SEAL_USE__UMUL128 */
/* #undef SEAL_USE__BITSCANREVERSE64 */
/* #undef SEAL_USE___BUILTIN_CLZLL */
/* #undef SEAL_USE___INT128 */
/* #undef SEAL_USE__ADDCARRY_U64 */
/* #undef SEAL_USE__SUBBORROW_U64 */
/* #undef SEAL_USE_AES_NI_PRNG */
/* #undef SEAL_USE_MSGSL */
/* #undef SEAL_USE_MSGSL_SPAN */
/* #undef SEAL_USE_MSGSL_MULTISPAN */
