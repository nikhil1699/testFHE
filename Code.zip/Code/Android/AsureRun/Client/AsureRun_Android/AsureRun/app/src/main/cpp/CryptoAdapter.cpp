// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
#include <iostream>
#include <chrono>
#include <cstdint>
#include <jni.h>
#include <math.h>
#include "base64.h"
#include "CryptoContext.h"
using namespace seal;
using namespace std;


uint64_t currentTimeMillis() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

extern "C" JNIEXPORT jlong JNICALL Java_com_microsoft_asurerun_model_ApplicationState_nativeCreateCryptoContext(JNIEnv *env, jclass type, jstring fileStorageDirectory, jint polyModulus, jint scale)
{ // 2nd Parameter used to be "jobject"
    const char *directory = env->GetStringUTFChars(fileStorageDirectory, nullptr);
    CryptoContext *context = createCryptoContext(directory, polyModulus);
    env->ReleaseStringUTFChars(fileStorageDirectory, directory);
    return reinterpret_cast<long>(context);
}

extern "C" JNIEXPORT void JNICALL Java_com_microsoft_asurerun_model_ApplicationState_nativeReleaseCryptoContext(JNIEnv *env, jclass type, jlong contextHandle)
{ // 2nd Parameter used to be "jobject"
    releaseCryptoContext(reinterpret_cast<CryptoContext*>(contextHandle));
}

extern "C" JNIEXPORT jstring JNICALL Java_com_microsoft_asurerun_model_ApplicationState_nativeEncryptSingle(
        JNIEnv *env, jclass type, jlong contextHandle, jdouble input) {
    double nativeInput = input;
    CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);
    return env->NewStringUTF(context->encrypt(nativeInput).c_str());

}

extern "C" JNIEXPORT jstring JNICALL Java_com_microsoft_asurerun_model_ApplicationState_nativeEncrypt(JNIEnv *env, jclass type, jlong contextHandle, jdoubleArray input)
{ // 2nd Parameter used to be "jobject"
    jsize inputLength = env->GetArrayLength(input);
    jdouble *rawArray = env->GetDoubleArrayElements(input, nullptr);

    // Reference: https://stackoverflow.com/questions/7278347/c-pointer-array-to-vector/15203325
    // On Lubuntu there is a red error line across "inputVector(rawArray, rawArray + inputLenght);
    // TODO: Find out if this is the case on Windows
    // Hopefully this shouldn't be an issue
    // TURNS OUT MICROSOFT CODED THIS THEMSELVES. It should most likely be fine
    vector<double> inputVector(rawArray, rawArray + inputLength);
    env->ReleaseDoubleArrayElements(input, rawArray, JNI_ABORT);

    CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);
    return env->NewStringUTF(context->encrypt(inputVector).c_str());
}


extern "C" JNIEXPORT jdoubleArray JNICALL Java_com_microsoft_asurerun_model_ApplicationState_nativeDecrypt(JNIEnv *env, jclass type, jlong contextHandle, jstring input)
{ // 2nd Parameter used to be "jobject"
    const char *rawInput = env->GetStringUTFChars(input, nullptr);
    CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);
    vector<double> output = context->decrypt(rawInput);
    env->ReleaseStringUTFChars(input, rawInput);
    jdoubleArray javaOutput = env->NewDoubleArray(output.size());
    env->SetDoubleArrayRegion(javaOutput, 0, output.size(), output.data());

    return javaOutput;
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_microsoft_asurerun_model_ApplicationState_nativeLoadLocalKeys(
        JNIEnv *env,
        // jobject,
        jclass type,
        jlong contextHandle,
        jstring publicKeyPath,
        jstring secretKeyPath)
{
    const char *publicKey = env->GetStringUTFChars(publicKeyPath, nullptr);
    const char *secretKey = env->GetStringUTFChars(secretKeyPath, nullptr);
    CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);
    bool result = context->loadLocalKeys(publicKey, secretKey);
    env->ReleaseStringUTFChars(publicKeyPath, publicKey);
    env->ReleaseStringUTFChars(secretKeyPath, secretKey);
    return result == true;
}

extern "C" JNIEXPORT void JNICALL Java_com_microsoft_asurerun_model_ApplicationState_nativeGenerateKeys(
    JNIEnv *env,
    // jobject,
    jclass type,
    jlong contextHandle,
    jstring publicKeyPath,
    jstring secretKeyPath,
    jstring galoisKeyPath,
    jstring galoisSingleStepKeyPath,
    jstring relinearizeKeyPath)
{
    const char *publicKey = env->GetStringUTFChars(publicKeyPath, nullptr);
    const char *secretKey = env->GetStringUTFChars(secretKeyPath, nullptr);
    const char *galoisKey = env->GetStringUTFChars(galoisKeyPath, nullptr);
    const char *galoisSingleStepKey = env->GetStringUTFChars(galoisSingleStepKeyPath, nullptr);
    const char *relinearizeKey = env->GetStringUTFChars(relinearizeKeyPath, nullptr);
    CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);
    context->generateKeys(publicKey, secretKey, galoisKey, galoisSingleStepKey, relinearizeKey);
    env->ReleaseStringUTFChars(publicKeyPath, publicKey);
    env->ReleaseStringUTFChars(secretKeyPath, secretKey);
    env->ReleaseStringUTFChars(galoisKeyPath, galoisKey);
    env->ReleaseStringUTFChars(galoisSingleStepKeyPath, galoisSingleStepKey);
    env->ReleaseStringUTFChars(relinearizeKeyPath, relinearizeKey);
}






extern "C" JNIEXPORT jstring JNICALL Java_com_microsoft_asurerun_model_ApplicationState_kld2 (
        JNIEnv *env,
        jclass type,
        jdoubleArray X_,
        jdoubleArray logX_,
        jdoubleArray Y_
        )

        {
            // Represents lists X, logX, and Y in C-Style Arrays
            jdouble *X = env->GetDoubleArrayElements(X_, NULL);
            jdouble *logX = env->GetDoubleArrayElements(logX_, NULL);
            jdouble *Y = env->GetDoubleArrayElements(Y_, NULL);
            int xLen = env->GetArrayLength(X_);
            int yLen = env->GetArrayLength(Y_);


            vector<Ciphertext> X_enc;
            vector<Ciphertext> logX_enc;

            // Hard-coded in 8192 for polymod degree value
            EncryptionParameters parms(scheme_type::CKKS);
            parms.set_poly_modulus_degree(2048);
            parms.set_coeff_modulus({
                                            0xffffffffffc0001, // 60 bits
                                            0x7fffffffffcc001, // 59 bits
                                            0x7fffffffffa4001, // 59 bits
                                            0xffffe80001       // 40 bits
                                    });
            auto context = SEALContext::Create(parms);

            // Not sure if all of these will be needed yet
            KeyGenerator keygen(context);
            auto public_key = keygen.public_key();
            auto secret_key = keygen.secret_key();

            Encryptor encryptor(context, public_key);
            Evaluator evaluator(context);
            Decryptor decryptor(context, secret_key);

            CKKSEncoder encoder(context);

            // Not sure if the scale is appropriate for our computations either
            double scale = parms.coeff_modulus().back().value();


            // Encrypt double results into Ciphertext lists X_enc and logX_enc
            for (int i = 0; i < xLen; i++) {
                Plaintext xTemp;
                Plaintext logXTemp;
                Ciphertext xElement;
                Ciphertext logXElement;


                encoder.encode(X[i], scale, xTemp);
                encoder.encode(logX[i], scale, logXTemp);

                encryptor.encrypt(xTemp, xElement);
                encryptor.encrypt(logXTemp, logXElement);

                X_enc.push_back(xElement);
                logX_enc.push_back(logXElement);
            }

            for (int i = 0; i < X_enc.size(); i++) {
                Plaintext temp;
                // Encode log(Y[i]) into Plaintext temp
                encoder.encode(log(Y[i]), scale, temp);
                // Double check that sub_plain_inplace does the same operatorion
                // as PySEAL's sub_plain
                evaluator.sub_plain_inplace(X_enc[i], temp);
                evaluator.multiply_inplace(X_enc[i], logX_enc[i]);
            }

            Ciphertext KLD_enc;
            evaluator.add_many(X_enc, KLD_enc);


            // Release memory after everything is done
            env->ReleaseDoubleArrayElements(Y_, Y, 0);
            env->ReleaseDoubleArrayElements(X_, X, 0);
            env->ReleaseDoubleArrayElements(logX_, logX, 0);

            // Here, we're basically implementing the FromSealObject method
            // from SEALWrapper.cpp
            stringstream stream;
            KLD_enc.save(stream);
            string result = stream.str();
            result = base64_encode(reinterpret_cast<const uint8_t *>(result.c_str()), result.size());

            // Release memory after everything is done
            env->ReleaseDoubleArrayElements(Y_, Y, 0);
            env->ReleaseDoubleArrayElements(X_, X, 0);
            env->ReleaseDoubleArrayElements(logX_, logX, 0);

            return env->NewStringUTF(result.c_str());
        }


// Kullback-Leibler Divergence of lists X and Y
extern "C" JNIEXPORT jobjectArray JNICALL Java_com_microsoft_asurerun_model_ApplicationState_kld(
        JNIEnv *env,
        jclass type,
        jobjectArray X_,
        jobjectArray logX_,
        jdoubleArray Y_,
        jlong contextHandle)

        {
            // Represents list Y in C-Style Array
            jdouble *Y = env->GetDoubleArrayElements(Y_, NULL);

            vector<string> x;
            vector<string> logx;

            // Convert arrays X_ and logX_ into vectors x and logx, respectively
            // Reference: https://stackoverflow.com/a/45989502
            // Convert array X_ to vector x
            int lenX_ = env->GetArrayLength(X_);

            for (int i = 0; i < lenX_; i++) {
                // Cast array element to string
                jstring jstr = (jstring) (env->GetObjectArrayElement(X_, i));

                // Convert Java string to std::string
                const jsize strLen = env->GetStringUTFLength(jstr);
                const char *charBuffer = env->GetStringUTFChars(jstr, (jboolean *) 0);
                string str(charBuffer, strLen);

                // Push back string to vector
                x.push_back(str);

                // Release memory
                env->ReleaseStringUTFChars(jstr, charBuffer);
                env->DeleteLocalRef(jstr);
            }

            // Convert array logX_ to vector logx
            int lenLogX_ = env->GetArrayLength(logX_);

            for (int i = 0; i < lenLogX_; i++) {
                // Cast array element to string
                jstring jstr = (jstring) (env->GetObjectArrayElement(logX_, i));

                // Convert Java string to std::string
                const jsize strLen = env->GetStringUTFLength(jstr);
                const char *charBuffer = env->GetStringUTFChars(jstr, (jboolean *) 0);
                string str(charBuffer, strLen);

                // Push back string to vector
                logx.push_back(str);

                // Release memory
                env->ReleaseStringUTFChars(jstr, charBuffer);
                env->DeleteLocalRef(jstr);
            }

            // These are essentially the parameters in the python kld implementation
            vector<Ciphertext> X;
            vector<Ciphertext> logX;

            // Add all elements of vector<string> x into vector<Ciphertext> X
            for (int i = 0; i < x.size(); i++) {
                Ciphertext temp;

                // Convert x[i] to Ciphertext, store in temp
                // This is essentially rewriting
                // SEALWrapper::ToSealObject from SEALWrapper.cpp
                x[i] = base64_decode(x[i]);
                stringstream stream(x[i]);
                temp.unsafe_load(stream);

                // Add temp to X
                X.push_back(temp);

            }

            // Add all elements of vector<string> logx into vector<Ciphertext> logX
            for (int i = 0; i < logx.size(); i++) {
                Ciphertext temp;

                // Convert logx[i] to Ciphertext, store in temp
                logx[i] = base64_decode(logx[i]);
                stringstream stream(logx[i]);
                temp.unsafe_load(stream);

                // Add temp to logX
                logX.push_back(temp);
            }

            CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);

             //EncryptionParameters parms(scheme_type::CKKS);
            // 8192 is a hard-coded value. Not sure if it's an appropriate number
            // for our computations yet
            // parms.set_poly_modulus_degree(8192);
            // parms.set_coeff_modulus(DefaultParams::coeff_modulus_128(8192));
             //auto context2 = SEALContext::Create(parms);

            // Not sure if all of these will be needed yet
            // KeyGenerator keygen(context);
            // auto public_key = keygen.public_key();
            // auto secret_key = keygen.secret_key();

            // Encryptor encryptor(context, public_key);
            //Evaluator evaluator(context2);
            // Decryptor decryptor(context, secret_key);

            uint64_t t_0 = currentTimeMillis();
            string KLD_enc = context->kld(X, logX, Y);
            uint64_t t_f = currentTimeMillis();

            uint64_t timeTaken = t_f - t_0;

            // Create a String[] that stores both the KLD result as well as time taken to run KLD
            jobjectArray result;
            result = (jobjectArray)env->NewObjectArray(2, env->FindClass("java/lang/String"),
                    env->NewStringUTF(""));

            env->SetObjectArrayElement(result, 0, env->NewStringUTF(KLD_enc.c_str()));
            env->SetObjectArrayElement(result, 1, env->NewStringUTF(to_string(timeTaken).c_str()));


            //CKKSEncoder encoder(context2);

            // Not sure if the scale is appropriate for our computations either
            //double scale = pow(2.0, 60);
            //for (int i = 0; i < X.size(); i++) {
            //    Plaintext temp;
            //    // Encode log(Y[i]) into Plaintext temp
            //    encoder.encode(log(Y[i]), scale, temp);
                // Double check that sub_plain_inplace does the same operatorion
                // as PySEAL's sub_plain
            //    evaluator.sub_plain_inplace(logX[i], temp);
            //    evaluator.multiply_inplace(X[i], logX[i]);
            //}

            //Ciphertext KLD_enc;
            //evaluator.add_many(X, KLD_enc);

            // Here, we're basically implementing the FromSealObject method
            // from SEALWrapper.cpp
            //stringstream stream;
            //KLD_enc.save(stream);
            //string result = stream.str();
            //result = base64_encode(reinterpret_cast<const uint8_t *>(result.c_str()), result.size());

            env->ReleaseDoubleArrayElements(Y_, Y, 0);

            // What this method returned originally. If the String[] array trick doesn't work,
            // revert back to this
            // return env->NewStringUTF(KLD_enc.c_str());
            return result;
        }






// Bhattacharyya coefficient between sqrtX and sqrtY
// TODO(In the future): Make separate methods for converting Java String[] to vector<std::string>
// as well as vector<std::string> to vector<seal::Ciphertext>
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_microsoft_asurerun_model_ApplicationState_bcCoeff(JNIEnv *env, jclass type,
                                                           jobjectArray sqrtX_,
                                                           jdoubleArray sqrtY__,
                                                           jlong contextHandle) {

    jdouble *sqrtY_ = env->GetDoubleArrayElements(sqrtY__, NULL);

    vector<string> sqrtx;

    // Convert array sqrtX_ into vector sqrtx
    int lenSqrtX = env->GetArrayLength(sqrtX_);

    for (int i = 0; i < lenSqrtX; i++) {
        // Cast array element to string
        jstring jstr = (jstring) (env->GetObjectArrayElement(sqrtX_, i));

        // Convert Java string to std::string
        const jsize strLen = env->GetStringUTFLength(jstr);
        const char *charBuffer = env->GetStringUTFChars(jstr, (jboolean *) 0);
        string str(charBuffer, strLen);

        // Push back string to vector
        sqrtx.push_back(str);

        // Release memory
        env->ReleaseStringUTFChars(jstr, charBuffer);
        env->DeleteLocalRef(jstr);
    }

    // This is essentially the SEAL object parameter in the python kld implementation
    vector<Ciphertext> sqrtX;

    // Add all elements of vector<string> sqrtx into vector<Ciphertext> sqrtX
    for (int i = 0; i < sqrtx.size(); i++) {
        Ciphertext temp;

        // Convert sqrtx[i] to Ciphertext, store in temp
        // This is essentially rewriting
        // SEALWrapper::ToSealObject from SEALWrapper.cpp
        sqrtx[i] = base64_decode(sqrtx[i]);
        stringstream stream(sqrtx[i]);
        temp.unsafe_load(stream);

        // Add temp to sqrtX
        sqrtX.push_back(temp);
    }

    CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);

    uint64_t t_0 = currentTimeMillis();
    string c_enc = context->bcCoeff(sqrtX, sqrtY_);
    uint64_t t_f = currentTimeMillis();

    uint64_t timeTaken = t_f - t_0;

    // Create a String[] that stores both the Bhattacharyya result
    // as well as time taken to run Bhattacharyya Coefficient
    jobjectArray result;
    result = (jobjectArray)env->NewObjectArray(2, env->FindClass("java/lang/String"),
                                               env->NewStringUTF(""));

    env->SetObjectArrayElement(result, 0, env->NewStringUTF(c_enc.c_str()));
    env->SetObjectArrayElement(result, 1, env->NewStringUTF(to_string(timeTaken).c_str()));

    env->ReleaseDoubleArrayElements(sqrtY__, sqrtY_, 0);

    // In case String[] method doesn't work, revert back to this return statement
    // return env->NewStringUTF(c_enc.c_str());

    return result;
}

extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_microsoft_asurerun_model_ApplicationState_cramer(JNIEnv *env, jclass type, jobjectArray P_,
                                                          jdoubleArray Q_, jlong contextHandle) {
    jdouble *Q = env->GetDoubleArrayElements(Q_, NULL);

    vector<string> p;

    // Convert array P_ into vector p
    int lenP = env->GetArrayLength(P_);
    for (int i = 0; i < lenP; i++) {
        // Cast array element to string
        jstring jstr = (jstring) (env->GetObjectArrayElement(P_, i));

        // Convert Java string to std::string
        const jsize strLen = env->GetStringUTFLength(jstr);
        const char *charBuffer = env->GetStringUTFChars(jstr, (jboolean *) 0);
        string str(charBuffer, strLen);

        // Push back string to vector
        p.push_back(str);

        // Release memory
        env->ReleaseStringUTFChars(jstr, charBuffer);
        env->DeleteLocalRef(jstr);
    }

    // This is essentially the SEAL object parameter in the python kld implementation
    vector<Ciphertext> P;

    // Add all elements of vector<string> p into vector<Ciphertext> P
    for (int i = 0; i < p.size(); i++) {
        Ciphertext temp;

        // Convert p[i] to Ciphertext, store in temp
        // This is essentially rewriting
        // SEALWrapper::ToSealObject from SEALWrapper.cpp
        p[i] = base64_decode(p[i]);
        stringstream stream(p[i]);
        temp.unsafe_load(stream);

        // Add temp to P
        P.push_back(temp);
    }

    CryptoContext *context = reinterpret_cast<CryptoContext*>(contextHandle);

    uint64_t t_0 = currentTimeMillis();
    string c_enc = context->cramer(P, Q);
    uint64_t t_f = currentTimeMillis();

    uint64_t timeTaken = t_f - t_0;

    // Create a String[] that stores both the Cramer result
    // as well as time taken to run Cramer's distance
    jobjectArray result;
    result = (jobjectArray)env->NewObjectArray(2, env->FindClass("java/lang/String"),
                                               env->NewStringUTF(""));
    env->SetObjectArrayElement(result, 0, env->NewStringUTF(c_enc.c_str()));
    env->SetObjectArrayElement(result, 1, env->NewStringUTF(to_string(timeTaken).c_str()));

    env->ReleaseDoubleArrayElements(Q_, Q, 0);

    return result;
}